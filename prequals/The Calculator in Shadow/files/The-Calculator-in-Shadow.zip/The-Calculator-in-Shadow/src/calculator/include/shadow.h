#ifndef H_SHADOW
#define H_SHADOW

#ifndef SUNBATH
#define IN_SHADOW \
  asm volatile(   \
    "obscure ra"  \
  );
#else
#define IN_SHADOW
#endif

void blue_hour (void);

#endif /* H_SHADOW */
