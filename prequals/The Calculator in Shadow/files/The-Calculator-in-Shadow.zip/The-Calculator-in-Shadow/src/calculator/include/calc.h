#ifndef H_CALC
#define H_CALC

#include <inttypes.h>

#define MAX_OPS 16

typedef enum error_kind error_kind;

typedef enum node_kind {
  NODE_NUMBER,
  NODE_PLUS,
  NODE_MINUS,
  NODE_TIMES,
  NODE_DIVIDE,
  NODE_POWER,
} node_kind;

typedef struct node_t {
  node_kind kind;
  union {
    struct {
      uint8_t id;
      struct node_t *node_l;
      struct node_t *node_r;
    } binop;
    int64_t value;
  } content;
} node_t;

error_kind secure_calc (char input[], node_t* node_root, int64_t* result);

#endif /* H_CALC */
